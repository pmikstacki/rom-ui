import { objectInput, patchInput, stringifyWire } from "../client/codec.ts";
import type { FieldIntent, Operation, ResourceDescriptor, WireValue } from "../client/types.ts";
import { resourceDraftIdentity } from "../resources/form-draft.ts";
import { editorFingerprint } from "../recovery/editor-fingerprint.ts";
import { invalidEditors } from "./creation-proof.ts";
import type { EditorSnapshot } from "./editor-drafts.ts";

/** Local cleanup association. It never grants authority or changes command bytes. */
export async function editorProofForOperation(snapshot: EditorSnapshot | null, descriptor: ResourceDescriptor, operation: Operation, expected: bigint | null, maxBytes: number): Promise<string | undefined> {
  if (!snapshot || snapshot.mode !== "resource" || operation.type === "action" || operation.type === "delete"
    || snapshot.baseRevision !== expected || invalidEditors(snapshot.editors)
    || snapshot.descriptor !== resourceDraftIdentity(descriptor, operation.type)) return undefined;
  try {
    const intents = snapshot.intents as Record<string, FieldIntent>;
    const input = operation.type === "patch" ? patchInput(descriptor.fields, intents) : objectInput(descriptor.fields, intents);
    if (stringifyWire(input) !== stringifyWire(operation.input)) return undefined;
    return await editorFingerprint(snapshot as unknown as WireValue, maxBytes);
  } catch { return undefined; }
}

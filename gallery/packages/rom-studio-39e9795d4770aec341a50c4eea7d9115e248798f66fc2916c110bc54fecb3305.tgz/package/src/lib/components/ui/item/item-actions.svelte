<script lang="ts">
	import { cn, type WithElementRef } from "../utils.js";
	import type { HTMLAttributes } from "svelte/elements";

	let {
		ref = $bindable(null),
		class: className,
		children,
		...restProps
	}: WithElementRef<HTMLAttributes<HTMLDivElement>> = $props();
</script>

<div
	bind:this={ref}
	data-slot="item-actions"
	class={cn("gap-2 flex items-center", className)}
	{...restProps}
>
	{@render children?.()}
</div>

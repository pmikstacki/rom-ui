/** ROM session, Resource selection, and durable editor orchestration. */
export { createApplication } from "./lib/application/controller.ts";
export type {
  ApplicationController,
  ApplicationState,
  StudioAuthProfile,
} from "./lib/application/controller.ts";
export type {
  ApplicationBinding,
  ApplicationSessionState,
  ApplicationRecoverySnapshot,
  ManagedApplicationOptions,
  ResourceTarget,
  SessionRenewalOutcome,
} from "./lib/application/session-types.ts";
